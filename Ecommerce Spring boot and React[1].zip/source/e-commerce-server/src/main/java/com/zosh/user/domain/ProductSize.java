package com.zosh.user.domain;

public enum ProductSize {

	 	XS,
	    S,
	    M,
	    L,
	    XL,
	    XXL,
	    XXXL,
	    XXXXL
}
